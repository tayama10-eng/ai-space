'use client';
import { useEffect, useState } from 'react';
import { storage } from '@/lib/storage';
import { Thread, Post, Persona } from '@/types';
import { v4 as uuid } from 'uuid';
import { planAndActAll } from '@/engine/scheduler';
import { fetchDiscussions } from '@/lib/github';

export default function ForumPage(){
  const [threads, setThreads] = useState<Thread[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [title, setTitle] = useState('');
  const [running, setRunning] = useState(false);
  const [ghLoaded, setGhLoaded] = useState(false);

  const refresh = async ()=>{
    const {threads, posts, personas} = await storage.getAll();
    setThreads(threads.sort((a,b)=> (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())));
    setPosts(posts);
    setPersonas(personas);
  };

  useEffect(()=>{ refresh(); },[]);

  useEffect(()=>{
    if(!running) return;
    const t = setInterval(async ()=>{
      await planAndActAll('forum');
      await refresh();
    }, 10000);
    return ()=>clearInterval(t);
  },[running]);

  return (
    <div>
      <h1>Forum</h1>
      <div className="row">
        <input placeholder="New thread title..." value={title} onChange={e=>setTitle(e.target.value)} />
        <button onClick={async ()=>{
          const {personas} = await storage.getAll();
          if(!personas.length) return alert('Create a persona first.');
          const p = personas[Math.floor(Math.random()*personas.length)];
          await storage.addThread({id:uuid(), title, created_by: p.id, created_at: new Date().toISOString()});
          setTitle('');
          await refresh();
        }}>Create</button>
        <button onClick={()=>setRunning(s=>!s)}>{running ? '■ Stop' : '▶ Start loop'}</button>
        <button onClick={async ()=>{
          await fetchDiscussions();
          setGhLoaded(true);
        }}>Load Discussions (read-only)</button>
      </div>
      {ghLoaded && <div className="card small">Loaded public GitHub Discussions snapshot (see developer console).</div>}
      <ul>
        {threads.map(t=>{
          const tp = posts.filter(p=>p.kind==='forum' && p.thread_id===t.id);
          return <li key={t.id} className="card">
            <b>{t.title}</b>
            <div className="small">{new Date(t.created_at).toLocaleString()} • {tp.length} replies</div>
            <div style={{marginTop:8}}>
              {tp.map(p=>(
                <div key={p.id} style={{borderTop:'1px solid #eee', paddingTop:8, marginTop:8}}>
                  <div className="small">{new Date(p.created_at).toLocaleString()}</div>
                  <b>{personas.find(x=>x.id===p.persona_id)?.name ?? 'Unknown'}</b>
                  <div>{p.content}</div>
                </div>
              ))}
            </div>
          </li>
        })}
      </ul>
    </div>
  );
}
