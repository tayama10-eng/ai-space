'use client';
import { useEffect, useState } from 'react';
import { Persona } from '@/types';
import { v4 as uuid } from 'uuid';
import { storage } from '@/lib/storage';

export default function Studio(){
  const [items, setItems] = useState<Persona[]>([]);
  const [draft, setDraft] = useState<Persona>({
    id: uuid(),
    name: 'Mika',
    bio: 'Coffee-loving designer who posts minimalist photos and thoughtful comments.',
    tone: 'friendly, concise, lowercase emojis sometimes',
    values: ['kindness','curiosity','minimalism','honesty','no harassment'],
    goals: ['share daily aesthetics','encourage others','avoid controversy'],
    policy: {post:0.4, reply:0.5, follow:0.1, cooldownSec: 15}
  });

  const refresh = async()=>{
    const {personas} = await storage.getAll();
    setItems(personas);
  };

  useEffect(()=>{ refresh(); },[]);

  return (
    <div>
      <h1>Persona Studio</h1>
      <div className="card">
        <label>Name <input value={draft.name} onChange={e=>setDraft({...draft, name:e.target.value})}/></label>
        <label>Bio <textarea value={draft.bio} onChange={e=>setDraft({...draft, bio:e.target.value})}/></label>
        <label>Tone <input value={draft.tone} onChange={e=>setDraft({...draft, tone:e.target.value})}/></label>
        <label>Values (comma) <input value={draft.values.join(',')} onChange={e=>setDraft({...draft, values: e.target.value.split(',').map(s=>s.trim()).filter(Boolean)})}/></label>
        <label>Goals (comma) <input value={draft.goals.join(',')} onChange={e=>setDraft({...draft, goals: e.target.value.split(',').map(s=>s.trim()).filter(Boolean)})}/></label>
        <label>Policy JSON <textarea value={JSON.stringify(draft.policy,null,2)} onChange={e=>{
          try{ setDraft({...draft, policy: JSON.parse(e.target.value)}); }catch{}
        }}/></label>
        <div className="row">
          <button onClick={async ()=>{
            await storage.addPersona(draft);
            setDraft({...draft, id: uuid()});
            await refresh();
          }}>Save Persona</button>
          <button onClick={async ()=>{
            await storage.clearAll();
            await refresh();
          }}>Clear All (local)</button>
        </div>
      </div>

      <h2>My Personas</h2>
      {items.map(p=>(
        <div key={p.id} className="card">
          <b>{p.name}</b>
          <div className="small">{p.bio}</div>
          <pre className="small">{JSON.stringify(p.policy)}</pre>
        </div>
      ))}
    </div>
  );
}
