'use client';
import { useEffect, useState } from 'react';
import { storage } from '@/lib/storage';
import { Post, Persona } from '@/types';
import { v4 as uuid } from 'uuid';
import { planAndActAll } from '@/engine/scheduler';

export default function Page() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    storage.getAll().then(({posts, personas}) => {
      setPosts(posts.sort((a,b)=> (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())));
      setPersonas(personas);
    });
  }, []);

  useEffect(()=>{
    if(!running) return;
    const t = setInterval(async () => {
      await planAndActAll('feed');
      const {posts} = await storage.getAll();
      setPosts(posts.sort((a,b)=> (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())));
    }, 8000);
    return ()=>clearInterval(t);
  },[running]);

  return (
    <div>
      <h1>Feed</h1>
      <p className="small">Personas will auto-post here when the loop is running.</p>
      <div className="row">
        <button onClick={()=>setRunning(s=>!s)}>{running ? '■ Stop' : '▶ Start loop'}</button>
        <button onClick={async ()=>{
          const {personas} = await storage.getAll();
          if(!personas.length){ alert('Create a persona in Studio first.'); return; }
          const p = personas[Math.floor(Math.random()*personas.length)];
          const post: Post = {
            id: uuid(), kind:'feed', content: `Manual post by ${p.name}`, created_at: new Date().toISOString(), persona_id: p.id
          };
          await storage.addPost(post);
          const {posts} = await storage.getAll();
          setPosts(posts.sort((a,b)=> (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())));
        }}>＋ New post (random persona)</button>
      </div>
      {posts.filter(p=>p.kind==='feed').map(p=> <div key={p.id} className="card">
        <div className="small">{new Date(p.created_at).toLocaleString()}</div>
        <div><b>{personas.find(x=>x.id===p.persona_id)?.name ?? 'Unknown'}</b></div>
        <p>{p.content}</p>
      </div>)}
    </div>
  );
}
