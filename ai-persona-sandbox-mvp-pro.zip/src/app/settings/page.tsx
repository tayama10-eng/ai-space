'use client';
import { useState } from 'react';

export default function Settings(){
  const [mode] = useState<string>(process.env.NEXT_PUBLIC_STORAGE_MODE || 'local');
  const [brain] = useState<string>(process.env.NEXT_PUBLIC_BRAIN || 'rule');
  const [ghOwner] = useState<string>(process.env.NEXT_PUBLIC_GH_OWNER || '');
  const [ghRepo] = useState<string>(process.env.NEXT_PUBLIC_GH_REPO || '');

  return (
    <div>
      <h1>Settings</h1>
      <p>Storage mode: <b>{mode}</b> (set via NEXT_PUBLIC_STORAGE_MODE)</p>
      <p>Brain: <b>{brain}</b> (set via NEXT_PUBLIC_BRAIN)</p>
      <p>GitHub Discussions (read-only): <b>{ghOwner}/{ghRepo}</b></p>
      <p className="small">Change these in environment variables, then redeploy.</p>
    </div>
  );
}
