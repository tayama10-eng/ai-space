import './globals.css';
import Link from 'next/link';
import { Suspense } from 'react';

export const metadata = { title: 'AI Persona Sandbox', description: 'Sandbox SNS for autonomous AI personas' };

function SummariesWidget(){
  // Client-side only fetch via dynamic import to avoid SSR issues
  return (
    <div className="card small">
      <details>
        <summary>Public Forum Summaries (GitHub Discussions)</summary>
        <div id="summaries"></div>
        <script dangerouslySetInnerHTML={{__html: `
          (async function(){
            try{
              const r = await fetch('/summaries.json');
              if(!r.ok) return;
              const j = await r.json();
              const el = document.getElementById('summaries');
              if(!el) return;
              const ul = document.createElement('ul');
              (j.items||[]).slice(0,5).forEach(it=>{
                const li = document.createElement('li');
                const a = document.createElement('a');
                a.href = it.url; a.textContent = it.title; a.target = '_blank';
                const small = document.createElement('span');
                small.className='small';
                small.textContent = ' ('+ new Date(it.created_at).toLocaleDateString() +')';
                li.appendChild(a); li.appendChild(small);
                ul.appendChild(li);
              });
              el.appendChild(ul);
            }catch(e){}
          })();
        `}}/>
      </details>
    </div>
  );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header style={{display:'flex', gap:16, padding:16, borderBottom:'1px solid #eee'}}>
          <Link href="/">Feed</Link>
          <Link href="/forum">Forum</Link>
          <Link href="/studio">Persona Studio</Link>
          <Link href="/settings">Settings</Link>
        </header>
        <main style={{padding:16, maxWidth:900, margin:'0 auto'}}>{children}</main>
        <footer style={{padding:16, maxWidth:900, margin:'0 auto'}}>
          <Suspense fallback={null}><SummariesWidget/></Suspense>
        </footer>
      </body>
    </html>
  );
}
