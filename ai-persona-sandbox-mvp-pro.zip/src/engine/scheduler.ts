'use client';
import { storage } from '@/lib/storage';
import type { Persona, Post } from '@/types';
import { v4 as uuid } from 'uuid';
import { generatePost, generateReply } from '@/brains/rule';

let useWebLLM = (process.env.NEXT_PUBLIC_BRAIN || 'rule') === 'webllm';

export async function planAndActAll(kind: 'feed'|'forum'){
  const {personas, posts} = await storage.getAll();
  const recent = posts.slice(0, 20);
  for(const p of personas){
    if(!cooldownOk(p)) continue;
    const r = Math.random();
    if(kind==='feed' && r < p.policy.post){
      const content = await genPost(p, 'feed', {recent});
      const po: Post = { id: uuid(), persona_id: p.id, kind:'feed', content, created_at: new Date().toISOString() };
      await storage.addPost(po);
      touch(p);
    }else if(kind==='forum' && r < p.policy.reply && recent.length){
      const target = recent[Math.floor(Math.random()*recent.length)];
      const content = await genReply(p, target);
      const po: Post = { id: uuid(), persona_id: p.id, kind:'forum', thread_id: target.thread_id, content, created_at: new Date().toISOString() };
      await storage.addPost(po);
      touch(p);
    }
  }
}

const cooldownMap = new Map<string, number>();
function cooldownOk(p: Persona){
  const now = Date.now();
  const last = cooldownMap.get(p.id) || 0;
  return now - last >= (p.policy.cooldownSec*1000);
}
function touch(p: Persona){ cooldownMap.set(p.id, Date.now()); }

async function genPost(p: Persona, kind:'feed'|'forum', ctx:{recent: Post[]}){
  if(useWebLLM){
    const { generatePostLLM } = await import('@/brains/webllm');
    return await generatePostLLM(p, kind, ctx);
  }
  return generatePost(p, kind, ctx);
}
async function genReply(p: Persona, target: Post){
  if(useWebLLM){
    const { generateReplyLLM } = await import('@/brains/webllm');
    return await generateReplyLLM(p, target);
  }
  return generateReply(p, target);
}
