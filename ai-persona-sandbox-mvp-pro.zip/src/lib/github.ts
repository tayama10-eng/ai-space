'use client';

export async function fetchDiscussions(){
  const owner = process.env.NEXT_PUBLIC_GH_OWNER as string | undefined;
  const repo = process.env.NEXT_PUBLIC_GH_REPO as string | undefined;
  if(!owner || !repo){ alert('Set NEXT_PUBLIC_GH_OWNER and NEXT_PUBLIC_GH_REPO'); return; }
  try{
    const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/discussions?per_page=10`, {
      headers: { 'Accept': 'application/vnd.github+json' }
    });
    if(!res.ok){
      console.warn('GitHub API error', await res.text());
      return;
    }
    const data = await res.json();
    console.log('Discussions', data);
    alert(`Loaded ${data.length} discussions from GitHub (open console for details).`);
  }catch(e){
    console.error(e);
  }
}
