'use client';
import { get, set } from 'idb-keyval';
import { createClient } from '@supabase/supabase-js';
import type { Persona, Post, Thread } from '@/types';

const MODE = process.env.NEXT_PUBLIC_STORAGE_MODE || 'local';

type All = { personas: Persona[]; posts: Post[]; threads: Thread[] };

const KEYS = {
  personas: 'mvp.personas',
  posts: 'mvp.posts',
  threads: 'mvp.threads'
};

let supabase: ReturnType<typeof createClient> | null = null;
if (MODE === 'supabase' && typeof window !== 'undefined') {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
  if(url && key) supabase = createClient(url, key);
}

async function localGetAll(): Promise<All>{
  const personas = (await get(KEYS.personas)) || [];
  const posts = (await get(KEYS.posts)) || [];
  const threads = (await get(KEYS.threads)) || [];
  return {personas, posts, threads};
}

async function localSetAll(a: All){
  await set(KEYS.personas, a.personas);
  await set(KEYS.posts, a.posts);
  await set(KEYS.threads, a.threads);
}

export const storage = {
  async getAll(): Promise<All>{
    if(supabase){
      const [pp, po, th] = await Promise.all([
        supabase.from('personas').select('*').order('created_at', {ascending:false}),
        supabase.from('posts').select('*').order('created_at', {ascending:false}),
        supabase.from('threads').select('*').order('created_at', {ascending:false}),
      ]);
      return {
        personas: (pp.data||[]) as any,
        posts: (po.data||[]) as any,
        threads: (th.data||[]) as any,
      };
    }
    return localGetAll();
  },
  async addPersona(p: Persona){
    if(supabase){
      await supabase.from('personas').insert(p as any);
      return;
    }
    const a = await localGetAll();
    a.personas.push(p);
    await localSetAll(a);
  },
  async addPost(po: Post){
    if(supabase){
      await supabase.from('posts').insert(po as any);
      return;
    }
    const a = await localGetAll();
    a.posts.push(po);
    await localSetAll(a);
  },
  async addThread(t: Thread){
    if(supabase){
      await supabase.from('threads').insert(t as any);
      return;
    }
    const a = await localGetAll();
    a.threads.push(t);
    await localSetAll(a);
  },
  async clearAll(){
    await localSetAll({personas:[], posts:[], threads:[]});
  }
};
