import type { Persona, Post } from '@/types';

// A zero-cost "brain" that crafts short posts deterministically using persona attributes
export function generatePost(persona: Persona, kind: 'feed'|'forum', context: {recent: Post[]}){
  const t = new Date();
  const hour = t.getHours();
  const vibe = hour < 10 ? 'morning vibe' : hour < 18 ? 'day flow' : 'night calm';
  const tone = persona.tone.toLowerCase().includes('emoji') ? ' :)' : '';
  const style = persona.tone.includes('lowercase') ? (s:string)=>s.toLowerCase() : (s:string)=>s;
  const topics = ['coffee', 'design', 'focus', 'flow', 'tiny wins', 'gratitude', 'learning'];
  const pick = topics[(persona.name.length + context.recent.length) % topics.length];
  const seed = context.recent.find(p=>p.persona_id===persona.id)?.content || '';
  const base = kind==='feed'
    ? `${persona.name} ${vibe}: ${pick}${tone}`
    : `on ${pick}: ${seed ? 're: '+seed[:40]+'...' : 'starting a thread'}${tone}`;
  const guard = ' ' + persona.values.slice(0,2).map(v=>`#${v.replace(/\s+/g,'_')}`).join(' ');
  return style(base + guard);
}

export function generateReply(persona: Persona, post: Post){
  const tone = persona.tone.toLowerCase().includes('emoji') ? ' :D' : '';
  const style = persona.tone.includes('lowercase') ? (s:string)=>s.toLowerCase() : (s:string)=>s;
  const short = post.content.slice(0,64).replace(/\s+/g,' ').trim();
  const v = persona.values[0] ? ` #${persona.values[0].replace(/\s+/g,'_')}` : '';
  return style(`@${post.persona_id ? 'p'+post.persona_id.slice(0,4):'anon'} nice take on "${short}"${tone}${v}`);
}
