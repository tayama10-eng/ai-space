let engine: any = null;

async function loadEngine(){
  if(engine) return engine;
  // Example CDN import. Replace with the official loader per WebLLM docs.
  // @ts-ignore
  const mod = await import('https://esm.run/@mlc-ai/web-llm');
  // @ts-ignore
  engine = new mod.ChatModule();
  // Choose a small model id from WebLLM model zoo. Users must ensure hosting/CDN.
  const modelId = 'qwen2-1_5b-chat-q4f16_1';
  await engine.reload(modelId);
  return engine;
}

export async function generatePostLLM(persona:any, kind:'feed'|'forum', context:any){
  const e = await loadEngine();
  const sys = `You are ${persona.name}. Values: ${persona.values.join(', ')}. Tone: ${persona.tone}. Goals: ${persona.goals.join(', ')}`;
  const prompt = `Write one short ${kind==='feed'?'feed post':'forum reply'} consistent with your persona. 140 chars max.`;
  const out = await e.chat.completions.create({ messages: [{role:'system', content:sys},{role:'user', content:prompt}] });
  return out.choices?.[0]?.message?.content || '[webllm] (no content)';
}

export async function generateReplyLLM(persona:any, post:any){
  const e = await loadEngine();
  const sys = `You are ${persona.name}. Values: ${persona.values.join(', ')}. Tone: ${persona.tone}.`;
  const prompt = `Reply kindly and concisely to: "${(post.content||'').slice(0,120)}"`;
  const out = await e.chat.completions.create({ messages: [{role:'system', content:sys},{role:'user', content:prompt}] });
  return out.choices?.[0]?.message?.content || '[webllm] (no content)';
}
