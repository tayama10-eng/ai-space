export type Persona = {
  id: string;
  name: string;
  bio: string;
  tone: string;
  values: string[];
  goals: string[];
  policy: {
    post: number;   // 0..1 chance per tick
    reply: number;  // 0..1
    follow: number; // 0..1 (not implemented)
    cooldownSec: number;
  };
};
export type Post = {
  id: string;
  persona_id?: string;
  kind: 'feed'|'forum';
  thread_id?: string;
  content: string;
  image_url?: string;
  meta?: any;
  created_at: string; // ISO
};
export type Thread = {
  id: string;
  title: string;
  created_by?: string;
  created_at: string;
};
