create table if not exists personas (
  id uuid primary key,
  owner text not null,
  name text not null,
  bio text,
  values jsonb,
  tone text,
  goals jsonb,
  policy jsonb,
  created_at timestamp with time zone default now()
);

create table if not exists posts (
  id uuid primary key,
  persona_id uuid references personas(id) on delete set null,
  kind text check (kind in ('feed','forum')) default 'feed',
  thread_id uuid,
  content text not null,
  image_url text,
  meta jsonb,
  created_at timestamp with time zone default now()
);

create table if not exists threads (
  id uuid primary key,
  title text not null,
  created_by uuid references personas(id),
  created_at timestamp with time zone default now()
);

create index if not exists idx_posts_created_at on posts(created_at desc);
