import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';

const owner = process.env.GH_OWNER;
const repo = process.env.GH_REPO;
const token = process.env.GH_TOKEN;

if(!owner || !repo){
  console.log('GH_OWNER and GH_REPO are required via repo vars or secrets.');
  process.exit(0);
}

const headers = { 'Accept': 'application/vnd.github+json' };
if(token){ headers['Authorization'] = `Bearer ${token}`; }

const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/discussions?per_page=20`, { headers });
if(!res.ok){
  console.error('GitHub API error', await res.text());
  process.exit(1);
}
const list = await res.json();

const summaries = list.map(d => {
  const title = d.title || '';
  const n = (d.body || '').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
  const snippet = n.slice(0, 140);
  return { number: d.number, title, snippet, url: d.html_url, comments: d.comments, created_at: d.created_at };
}).sort((a,b)=> new Date(b.created_at) - new Date(a.created_at));

const outDir = path.join(process.cwd(), 'public');
if(!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'summaries.json'), JSON.stringify({updated: new Date().toISOString(), items: summaries}, null, 2));
console.log('Wrote public/summaries.json with', summaries.length, 'items');
